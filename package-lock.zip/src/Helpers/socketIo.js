// const socketIo = require("socket.io");

// let io;
// const deliveryPartners = {}; // Store real-time partner locations

// module.exports = {
//   init: (server) => {
//     io = socketIo(server, {
//       cors: {
//         origin: "*",
//         methods: ["GET", "POST"],
//         allowedHeaders: ["Content-Type"],
//         credentials: true,
//       },
//     });

//     io.on("connection", (socket) => {
//       console.log(`Delivery partner connected: ${socket.id}`);

//       // Receive live location updates from the delivery partner
//       socket.on("updateLocation", (data) => {
//         console.log(" Location update received:", data);
//         deliveryPartners[socket.id] = data;
//         io.emit("partnerLocationUpdate", data);
//         s;
//       });

//       //  Handle disconnection
//       socket.on("disconnect", () => {
//         console.log(` Partner disconnected: ${socket.id}`);
//         delete deliveryPartners[socket.id];
//         io.emit("partnerDisconnected", socket.id);
//       });
//     });

//     return io;
//   },

//   getIo: () => {
//     if (!io) {
//       throw new Error("Socket.io not initialized!");
//     }
//     return io;
//   },
// };
// src/Helpers/socketIo.js
const { Server } = require("socket.io");

const initializeSocket = (port) => {
  const io = new Server(port, {
    cors: {
      origin: "http://localhost:5173",
      methods: ["GET", "POST"],
    },
  });

  const sellers = new Map();
  const deliveryPartners = {};

  io.on("connection", (socket) => {
    console.log("A user connected:", socket.id);

    // When a seller joins, store their socket ID
    socket.on("registerSeller", (sellerId) => {
      sellers.set(sellerId, socket.id);
      console.log(`Seller ${sellerId} connected with socket ID ${socket.id}`);
    });

    // Handle disconnection
    socket.on("disconnect", () => {
      for (let [sellerId, socketId] of sellers) {
        if (socketId === socket.id) {
          sellers.delete(sellerId);
          console.log(`Seller ${sellerId} disconnected`);
          break;
        }
      }
    });
  });

  return { io, sellers };
};

module.exports = { initializeSocket };
